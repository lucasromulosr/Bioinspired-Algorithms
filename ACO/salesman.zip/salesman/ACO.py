import numpy as np
from typing import List
import pandas as pd

# solucao da 26 eh 937
n = 26
max_iter = 50
stop_condition = max_iter / 10

with open(f'{n}_distances', 'r') as file:
	distances = [line.strip().split() for line in file]
	distances = np.matrix(distances, dtype=int)

with open(f'{n}_solution', 'r') as file:
	solution = [int(line.strip()) - 1 for line in file]

pheromone = [0 if i == j else pow(10, -16) for i in range(n) for j in range(n)]
pheromone = np.matrix(np.array_split(pheromone, n))


class Ant:
	def __init__(self, city):
		self.path = [city]
		self.city = city
		self.fitness = None

	def fitness_function(self):
		self.fitness = objective_function(self.path)

	def __str__(self):
		return f'{self.path}, {self.fitness}'

	def __eq__(self, other):
		for i in range(n):
			if not self.fitness == other.fitness:
				return False
			if not self.path == other.path:
				return False
		return True

	@classmethod
	def compare_populations(cls, actual, last):
		if not actual or not last:
			return False
		for i in range(n):
			if not actual[i] == last[i]:
				return False
		return True


def objective_function(x):
	summ = distances[x[n - 1], x[0]]
	summ += sum([distances[x[i], x[i + 1]] for i in range(n - 1)])
	return summ


def generate_ants():
	return [Ant(i) for i in range(n)]


def population_fitness(ants: List[Ant]):
	for ant in ants:
		ant.fitness_function()


def ants_move(ants: List[Ant]):
	for ant in ants:
		for _ in range(n - 1):

			cities = [i for i in range(n) if i not in ant.path]
			probabilities = [np.nan for _ in cities]

			summ = 0
			for i in range(len(cities)):
				value = pow(pheromone[ant.city, cities[i]], alpha)
				value *= 1 / pow(distances[ant.city, cities[i]], beta)
				probabilities[i] = value
				summ += value
			probabilities /= summ

			best = np.argmax(probabilities)
			ant.path.append(cities[best])
			ant.city = cities[best]


def ant_deposit_pheromone(ant: Ant, add_factor: float):
	pheromone[ant.path[n - 1], ant.path[0]] += add_factor
	for i in range(n - 1):
		pheromone[ant.path[i], ant.path[i + 1]] += add_factor


def ant_system_update(ants: List[Ant]):
	global pheromone
	pheromone *= (1 - ro)
	for ant in ants:
		add_factor = Q / ant.fitness
		ant_deposit_pheromone(ant, add_factor)


def elitism_ant_system_update(ants: List[Ant]):
	ant_system_update(ants)

	# e = 0.8
	best = np.argmin([ant.fitness for ant in ants])
	ant = ants[best]
	add_factor = e * Q / ant.fitness
	ant_deposit_pheromone(ant, add_factor)


def rank_based_ant_system_update(ants: List[Ant]):
	global pheromone
	pheromone *= (1 - ro)
	# w = int(n / 3)
	ants.sort(key=lambda x: x.fitness)
	bests = ants[:w]

	for r in range(w):
		add_factor = (w - r) * Q / bests[r].fitness
		ant_deposit_pheromone(bests[r], add_factor)


def ant_colony_system_update(ants: List[Ant]):
	global pheromone

	best = np.argmin([ant.fitness for ant in ants])
	best = ants[best]
	add_factor = ro * best.fitness
	ant_deposit_pheromone(best, add_factor)

	# csi = 0.1
	for ant in ants:
		if ant != best:
			pheromone[ant.path[n - 1], ant.path[0]] *= (1 - csi)
			pheromone[ant.path[n - 1], ant.path[0]] += csi * pow(10, -16)
			for i in range(n - 1):
				pheromone[ant.path[i], ant.path[i + 1]] *= (1 - csi)
				pheromone[ant.path[i], ant.path[i + 1]] += csi * pow(10, -16)


def main():
	last_ants = None
	stop = 0
	best_solutions = []

	pheromone_updates = {
		1: ant_system_update,
		2: elitism_ant_system_update,
		3: rank_based_ant_system_update,
		4: ant_colony_system_update,
	}
	c = 0
	for c in range(max_iter):

		ants = generate_ants()

		ants_move(ants)

		population_fitness(ants)

		update_method = pheromone_updates.get(method)
		update_method(ants)

		stop = (0, stop + 1)[Ant.compare_populations(ants, last_ants)]
		if stop == stop_condition:
			break
		else:
			last_ants = ants[:]

		best_solutions.append(np.min([ant.fitness for ant in ants]))

	instance = {
		'alpha': alpha, 'beta': beta, 'ro': '%.1f' % ro, 'Q': Q
	}
	if e:
		instance.update({'e': '%.1f' % e})
	if w:
		instance.update({'w': '%.1f' % w})
	if csi:
		instance.update({'csi': '%.1f' % csi})
	instance.update({
		'iter': c, 'best': np.min(best_solutions), 'mean': np.mean(best_solutions)
	})
	instances.append(instance)
	print(instance)


if __name__ == '__main__':
	e = w = csi = None

	# for method in [1, 2, 3, 4]:
	# 	instances = []
	#
	# 	for alpha in range(0, 10, 1):
	# 		for beta in range(0, 10, 1):
	# 			for ro in np.arange(0., 1.01, 0.1):
	# 				for Q in range(0, 501, 100):
	#
	# 					# ant system
	# 					if method == 1:
	# 						main()
	# 					# elitism
	# 					if method == 2:
	# 						for e in np.arange(0.5, 2.1, 0.5): main()
	# 					# rank based
	# 					if method == 3:
	# 						for w in range(int(n/4), int(n+1), int(n/4)): main()
	# 					# ant colony
	# 					if method == 4:
	# 						for csi in np.arange(0.0, 1.01, 0.1): main()
	#
	# 					e = w = csi = None
	#
	# 	df = pd.DataFrame(instances)
	# 	df.to_csv(f'output_method_{method}')

	solutions = []
	for method in [1, 2, 3]:
		df = pd.read_csv(f'output_method_{method}')
		solutions.append(np.min(df['best']))
	with open('output', 'w') as file:
		for s in solutions:
			file.write(str(s))
